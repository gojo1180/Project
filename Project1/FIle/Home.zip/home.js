let slideIndex = 0;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}


function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 6000); // Change image every 2 seconds
}

//---------------------------------------------

  const searchInput = document.getElementById('searchInput');
  const searchResults = document.getElementById('searchResults');
  
  
  const games = [
      { name: 'Mobile Legends', image: '../IMG/mobile-legends.webp', url: '/FIle/ml/ml.html' },
      { name: 'PUBG', image: '../IMG/pubg-mobile.webp', url: 'pubg.html' },
      { name: 'Genshin Impact', image: '../IMG/genshin-impact.webp', url: '/FIle/Genshin/Kikir.html'}
      // Tambahkan game lainnya sesuai kebutuhan
  ];
  
  // Fungsi untuk menampilkan hasil pencarian
  function showSearchResults(results) {
      // Bersihkan hasil sebelumnya
      searchResults.innerHTML = '';
  
      // Jika hasil pencarian kosong, sembunyikan searchResults
      if (results.length === 0) {
          searchResults.style.display = 'none';
          return;
      }
  
      // Buat elemen untuk setiap hasil pencarian
      results.forEach(game => {
          const gameElement = document.createElement('a');
          gameElement.classList.add('search-result');
  
          // Tambahkan gambar dan nama game
          const image = document.createElement('img');
          image.src = game.image;
          image.alt = game.name;
          gameElement.appendChild(image);
  
          const name = document.createElement('p');
          name.textContent = game.name;
          gameElement.appendChild(name);
  
          // Tambahkan event listener untuk mengarahkan ke halaman game saat di klik
          gameElement.addEventListener('click', () => {
              window.location.href = game.url;
          });
          // d
  
          searchResults.appendChild(gameElement);
      });
  
      // Tampilkan searchResults setelah selesai membangun hasil pencarian
      searchResults.style.display = 'block';
  }
  
  // Event listener untuk input pencarian
  searchInput.addEventListener('input', () => {
      const query = searchInput.value.toLowerCase();
      const filteredGames = games.filter(game =>
          game.name.toLowerCase().includes(query)
      );
      showSearchResults(filteredGames);
  });
  
  // Sembunyikan searchResults saat halaman dimuat
  searchResults.style.display = 'none';

